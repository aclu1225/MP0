//Names: Austin Lu & Yufan Yang
//Date Due: September 07, 2020
//Assignment: MP0
//Used Example-MP-Solution on github provided for this assignment

package main
import (
	"./emails"
	"bufio"
	"bytes"
	"encoding/gob"
	"fmt"
	"net"
	"os"
	"strings"
	"time"
)
func main(){

	arguments :=os.Args
	if len(arguments)==1{
		fmt.Println("Please provide host:port.")
		return
	}

	CONNECT:=arguments[1]
	c,err:=net.Dial("tcp",CONNECT)
	if err!=nil{
		fmt.Println(err)
		return
	}
	defer c.Close()
	reader:=bufio.NewReader(os.Stdin)
	fmt.Println("Enter your message: ")
	text,_:=reader.ReadString('\n')
	input:= strings.Split(text,";")
	time,err:=time.Parse("2006-01-02 15:04",input[2])
	var m= emails.Email{input[0],input[1],time,input[3],input[4]}
	bin_buf := new(bytes.Buffer)
	gobobj := gob.NewEncoder(bin_buf)
	gobobj.Encode(m)
	c.Write(bin_buf.Bytes())
	message, _ := bufio.NewReader(c).ReadString('\n')
	fmt.Print("Message from server: "+message)
}

