package email_go

//Importing fmt, time, and strings
import (
	"time"
)

//Defining message types of the email
type Email struct {
	To      string
	From    string
	Title   string
	Content string
	Date    time.Time

