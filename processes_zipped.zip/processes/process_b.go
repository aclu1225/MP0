//Names: Austin Lu & Yufan Yang
//Date Due: September 07, 2020
//Assignment: MP0
//Used Example-MP-Solution on github provided for this assignment

package main


import (
	"./emails"
	"bytes"
	"encoding/gob"
	"fmt"
	"net"
	"os"
)


type processB struct {
	e emails.Email
}
func main() {
	arguments := os.Args
	if len(arguments) == 1 {
		fmt.Println("Please provide port number")
		return
	}

	PORT := ":" + arguments[1]
	l, err := net.Listen("tcp", PORT)
	if err != nil {
		fmt.Println(err)
		return
	}
	defer l.Close()

	c, err := l.Accept()
	if err != nil {
		fmt.Println(err)
		return
	}


	tmp := make([]byte, 500)
	for {
		_, err = c.Read(tmp)
		// convert bytes into Buffer (which implements io.Reader/io.Writer)
		tmpbuff := bytes.NewBuffer(tmp)

		tmpstruct := new(processB)

		// creates a decoder object
		gobobj := gob.NewDecoder(tmpbuff)

		// decodes buffer and unmarshals it into a Message struct
		gobobj.Decode(tmpstruct)

		// lets print out!
		fmt.Println(tmpstruct) // reflects.TypeOf(tmpstruct) == Message{}
		c.Write([]byte("message received"))
		break
	}


}
